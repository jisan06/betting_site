<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/bootstrap.min.css">
<!-- fontawesome icon  -->
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/fontawesome.min.css">
<!-- flaticon css -->
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/fonts/flaticon.css">
<!-- animate.css -->
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/animate.css">
<!-- Owl Carousel -->
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/owl.carousel.min.css">
<!-- magnific popup -->
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/magnific-popup.css">
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/odometer.min.css">
<!-- stylesheet -->
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/style.css">
<!-- responsive -->
<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/responsive.css">

<link rel="stylesheet" href="{{ asset('public/frontend') }}/assets/css/custom_style.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />

{{-- data table css --}}
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.5/css/responsive.bootstrap.min.css">