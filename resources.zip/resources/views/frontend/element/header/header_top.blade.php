<div id="navbar" class="header-top header-bottom">
    <div class="container">
        <div class="row">
            <div class="col-xl-5 col-lg-5 col-sm-5">
                <div class="left-area">
                    <ul>
                        <li>
                            <span class="icon">
                                <i class="far fa-calendar-alt"></i>
                            </span>
                            <span class="text">
                                <span id="date"></span>
                                <span id="month"></span>
                                <span id="year"></span>
                            </span>
                        </li>
                        <li>
                            <span class="icon">
                                <i class="far fa-clock"></i>
                            </span>
                            <span class="text clocks">
                                <span id="hours"></span>:<span id="minutes"></span>:<span id="seconds"></span> <span id="amPm"></span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="col-xl-3 col-lg-3 col-sm-2 d-xl-flex d-lg-flex d-block align-items-center">
                <div class="left-area">
                    <ul>
                        <li>
                            <div class="logo">
                                <a href="{{ url('/') }}">
                                    <img src="{{ asset('public/frontend') }}/assets/img/logo.png" alt="logo">
                                </a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-sm-5">
                <div class="right-area">
                    <ul>
                        @if(Auth::guard('customer')->user())
                            <li>
                                <a class="link">
                                    ৳ 
                                    <span id="balance">
                                        {{number_format(Auth::guard('customer')->user()->balance, 2, '.', '')}}
                                    </span>
                                </a>
                            </li>
                            <li>
                                <a class="link" href="{{ route('user.dashboard') }}">
                                    <svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="user-circle" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512" class="svg-inline--fa fa-user-circle fa-w-16 fa-fw fa-2x">
                                        <path fill="currentColor" d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm128 421.6c-35.9 26.5-80.1 42.4-128 42.4s-92.1-15.9-128-42.4V416c0-35.3 28.7-64 64-64 11.1 0 27.5 11.4 64 11.4 36.6 0 52.8-11.4 64-11.4 35.3 0 64 28.7 64 64v13.6zm30.6-27.5c-6.8-46.4-46.3-82.1-94.6-82.1-20.5 0-30.4 11.4-64 11.4S204.6 320 184 320c-48.3 0-87.8 35.7-94.6 82.1C53.9 363.6 32 312.4 32 256c0-119.1 96.9-216 216-216s216 96.9 216 216c0 56.4-21.9 107.6-57.4 146.1zM248 120c-48.6 0-88 39.4-88 88s39.4 88 88 88 88-39.4 88-88-39.4-88-88-88zm0 144c-30.9 0-56-25.1-56-56s25.1-56 56-56 56 25.1 56 56-25.1 56-56 56z" class=""></path>
                                    </svg>
                                    My Account
                                </a>
                            </li>
                            <li>
                                <a class="link" href="{{ route('user.logout') }}">
                                    <i class="fa fa-sign-out-alt"></i>
                                    Logout
                                </a>
                            </li>
                        @else
                            <li>
                                <a class="link" href="{{ route('user.registration') }}">
                                    <svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="user-circle" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512" class="svg-inline--fa fa-user-circle fa-w-16 fa-fw fa-2x"><path fill="currentColor" d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm128 421.6c-35.9 26.5-80.1 42.4-128 42.4s-92.1-15.9-128-42.4V416c0-35.3 28.7-64 64-64 11.1 0 27.5 11.4 64 11.4 36.6 0 52.8-11.4 64-11.4 35.3 0 64 28.7 64 64v13.6zm30.6-27.5c-6.8-46.4-46.3-82.1-94.6-82.1-20.5 0-30.4 11.4-64 11.4S204.6 320 184 320c-48.3 0-87.8 35.7-94.6 82.1C53.9 363.6 32 312.4 32 256c0-119.1 96.9-216 216-216s216 96.9 216 216c0 56.4-21.9 107.6-57.4 146.1zM248 120c-48.6 0-88 39.4-88 88s39.4 88 88 88 88-39.4 88-88-39.4-88-88-88zm0 144c-30.9 0-56-25.1-56-56s25.1-56 56-56 56 25.1 56 56-25.1 56-56 56z" class=""></path></svg>
                                    Registration
                                </a>
                            </li>
                            <li>
                                <a class="link" href="{{ route('user.login') }}">
                                    <svg aria-hidden="true" focusable="false" data-prefix="fal" data-icon="user-circle" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512" class="svg-inline--fa fa-user-circle fa-w-16 fa-fw fa-2x"><path fill="currentColor" d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm128 421.6c-35.9 26.5-80.1 42.4-128 42.4s-92.1-15.9-128-42.4V416c0-35.3 28.7-64 64-64 11.1 0 27.5 11.4 64 11.4 36.6 0 52.8-11.4 64-11.4 35.3 0 64 28.7 64 64v13.6zm30.6-27.5c-6.8-46.4-46.3-82.1-94.6-82.1-20.5 0-30.4 11.4-64 11.4S204.6 320 184 320c-48.3 0-87.8 35.7-94.6 82.1C53.9 363.6 32 312.4 32 256c0-119.1 96.9-216 216-216s216 96.9 216 216c0 56.4-21.9 107.6-57.4 146.1zM248 120c-48.6 0-88 39.4-88 88s39.4 88 88 88 88-39.4 88-88-39.4-88-88-88zm0 144c-30.9 0-56-25.1-56-56s25.1-56 56-56 56 25.1 56 56-25.1 56-56 56z" class=""></path></svg>
                                    Login
                                </a>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>