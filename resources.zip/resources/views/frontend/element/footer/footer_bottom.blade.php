<!-- copyright footer begin -->
<div class="copyright-footer">
    <div class="container">
        <div class="row justify-content-between">
            <div class="col-xl-5 col-md-6 col-lg-6 d-lg-flex d-lg-flex d-block align-items-center">
                <p class="copyright-text">
                    <a href="#">PerediOn</a> © {{Date('Y')}}. PRIVACY POLICY
                </p>
            </div>
            <div class="text-right col-md-6 col-xl-4 col-lg-6 d-xl-flex d-lg-flex d-block align-items-center">
                <p class="copyright-text">
                    Powerd By <a>Self</a>
                </p>
            </div>
        </div>
    </div>
</div>
<!-- copyright footer end -->