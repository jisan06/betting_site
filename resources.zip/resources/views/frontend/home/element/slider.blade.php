<div class="banner" style='background: url("{{ asset($slider->image) }}") bottom center no-repeat'>
    <div class="container">
        <div class="banner-content">
            <div class="row justify-content-xl-start justify-content-lg-center justify-content-md-center">
                <div class="col-xl-12 col-lg-12 col-md-12 col-12 d-xl-flex d-lg-flex d-block align-items-center">
                    <div class="text-content">
                        <h1>{{$slider->first_title}}</h1>
                        <h4>{{$slider->second_title}}</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
